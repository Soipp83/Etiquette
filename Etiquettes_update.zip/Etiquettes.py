import requests
import pyodbc
import time
import os, sys, zipfile, io
import tkinter as tk
from tkinter import ttk, messagebox

# ✅ Version actuelle
CURRENT_VERSION = "1.0.1"
VERSION_URL = "https://1drv.ms/t/c/75171d567faf3e01/ETro3d4ZQ4tGgNlxuElznHoBPdPOiAG3_rZbLOvpdQyTWg?e=Nw8Enh"
UPDATE_URL = "https://1drv.ms/u/c/75171d567faf3e01/EVghFOY2w05Gq2GFDn8Xge4BhlBMrbWlkhsq0oNWSs5ONA?e=Jb49R0"

mdb_file = r"C:\Etiquettes\Liste.mdb"
word_template = r"C:\Etiquettes\Etiquettes.docx"
output_doc = r"C:\Etiquettes\Etiquettes_Fusionnees.docx"

keywords = {
    "Architectes": ["architecte"],
    "Plaquistes": ["plaquiste", "plâtre", "plâtrier"],
    "Carreleurs": ["carrelage", "carreleur", "carreau"]
}

# ------------------- ✅ MISE A JOUR -------------------
def check_update():
    try:
        resp = requests.get(VERSION_URL, timeout=5)
        if resp.status_code == 200:
            latest_version = resp.text.strip()
            if latest_version > CURRENT_VERSION:
                return latest_version
    except:
        pass
    return None

def do_update():
    try:
        resp = requests.get(UPDATE_URL, stream=True, timeout=10)
        if resp.status_code == 200:
            z = zipfile.ZipFile(io.BytesIO(resp.content))
            extract_path = os.path.dirname(os.path.abspath(sys.argv[0]))
            z.extractall(extract_path)
            messagebox.showinfo("Mise à jour", "✅ Mise à jour appliquée.\nRedémarrage…")
            os.execl(sys.executable, sys.executable, *sys.argv)
        else:
            messagebox.showerror("Erreur mise à jour", f"Téléchargement impossible : {resp.status_code}")
    except Exception as e:
        messagebox.showerror("Erreur mise à jour", str(e))

# ------------------- ✅ RECHERCHE -------------------
def reverse_geocode(lat, lon):
    url = "https://nominatim.openstreetmap.org/reverse"
    params = {"format": "json", "lat": lat, "lon": lon, "addressdetails": 1}
    resp = requests.get(url, params=params, headers={"User-Agent": "AccessSync/1.0"})
    if resp.status_code == 200:
        data = resp.json()
        addr = data.get("address", {})
        return addr.get("road",""), addr.get("house_number",""), addr.get("postcode","")
    return "", "", ""

def get_profession(city, selected_job, progress_var, log_text):
    """Recherche ciblée selon métier"""

    if selected_job == "Architectes":
        query = f"""
        [out:json];
        area["name"="{city}"]->.searchArea;
        (
          node["office"="architect"](area.searchArea);
          way["office"="architect"](area.searchArea);
          relation["office"="architect"](area.searchArea);
        );
        out center;
        """
    else:
        query = f"""
        [out:json];
        area["name"="{city}"]->.searchArea;
        (
          node["craft"](area.searchArea);
          node["shop"](area.searchArea);
          node["office"="company"](area.searchArea);
        );
        out center;
        """

    url = "https://overpass-api.de/api/interpreter"
    resp = requests.post(url, data={'data': query})
    if resp.status_code != 200:
        log_text.insert(tk.END, f"❌ Erreur Overpass {resp.status_code}\n")
        return []

    data = resp.json()
    elements = data.get("elements", [])
    log_text.insert(tk.END, f"🌍 {len(elements)} éléments trouvés avant filtrage\n")
    log_text.update()

    if not elements:
        return []

    kw = keywords[selected_job]
    results = []

    for i, element in enumerate(elements, start=1):
        tags = element.get("tags", {})
        nom = tags.get("name", "")
        lat = element.get("lat") or element.get("center", {}).get("lat")
        lon = element.get("lon") or element.get("center", {}).get("lon")

        if selected_job == "Architectes":
            keep = True
        else:
            keep = any(k in nom.lower() for k in kw)

        if not nom or not keep:
            continue

        street = tags.get("addr:street","")
        housenumber = tags.get("addr:housenumber","")
        postcode = tags.get("addr:postcode","")
        ville = tags.get("addr:city", city)

        if (not street or not postcode) and lat and lon:
            r_street, r_num, r_pc = reverse_geocode(lat, lon)
            if not street: street = r_street
            if not housenumber: housenumber = r_num
            if not postcode: postcode = r_pc
            time.sleep(1)

        adresse_complete = (street + " " + housenumber).strip()
        results.append({
            "societe": nom,
            "adresse": adresse_complete,
            "ville": ville,
            "postcode": postcode
        })

        progress_var.set(int((i/len(elements))*100))
        log_text.insert(tk.END, f"✓ {nom} | {adresse_complete} | {ville} | {postcode}\n")
        log_text.see(tk.END)
        log_text.update()

    return results

# ------------------- ✅ ACCESS + WORD -------------------
def connect_access():
    return pyodbc.connect(r"Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={}".format(mdb_file))

def clear_access_table():
    conn = connect_access()
    cur = conn.cursor()
    cur.execute("DELETE FROM [Office Adress List]")
    conn.commit()
    conn.close()

def insert_into_access(data_list):
    conn = connect_access()
    cur = conn.cursor()
    for a in data_list:
        cur.execute("""
            INSERT INTO [Office Adress List]
            ([Civilité],[Prénom],[Nom],[Nom de la société],
             [Adresse Ligne 1],[Adresse Ligne 2],[Ville],[Département],[Code postal],[Pays])
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, ('','','', a['societe'], a['adresse'],'', a['ville'],'', a['postcode'],'France'))
    conn.commit()
    conn.close()

def fusion_word(imprimer=False):
    if not os.path.exists(word_template):
        messagebox.showerror("Erreur", f"Modèle Word introuvable :\n{word_template}")
        return
    import win32com.client
    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    doc = word.Documents.Open(word_template)
    doc.MailMerge.OpenDataSource(
        Name=mdb_file,
        Connection="TABLE Office Adress List",
        SQLStatement="SELECT * FROM [Office Adress List]"
    )
    doc.MailMerge.Destination = 0
    doc.MailMerge.Execute()
    resdoc = word.ActiveDocument
    resdoc.SaveAs2(output_doc)
    if imprimer:
        resdoc.PrintOut()
        resdoc.Close(False)
        doc.Close(False)
        word.Quit()
        messagebox.showinfo("Impression", "✅ Étiquettes imprimées.")
    else:
        resdoc.Close(False)
        doc.Close(False)
        word.Quit()
        messagebox.showinfo("Fusion terminée", f"✅ Étiquettes générées :\n{output_doc}")

# ------------------- ✅ ACTIONS GUI -------------------
def lancer_import():
    city = entry_ville.get().strip()
    job = combo_metier.get()
    if not city:
        messagebox.showwarning("Ville manquante","Veuillez entrer une ville.")
        return
    if not job or job not in keywords:
        messagebox.showwarning("Métier manquant","Choisir un corps de métier.")
        return

    log_text.delete(1.0, tk.END)
    progress_var.set(0)
    root.update()

    if not messagebox.askokcancel("Confirmation", "Cela va VIDER la table Access avant import.\nContinuer ?"):
        return

    log_text.insert(tk.END, "🗑 Vidage de la table Access...\n")
    root.update()
    clear_access_table()
    log_text.insert(tk.END, "✅ Table vidée.\n\n")

    log_text.insert(tk.END, f"🔍 Recherche des {job.lower()} sur {city}...\n")
    root.update()

    results = get_profession(city, job, progress_var, log_text)
    if not results:
        messagebox.showinfo("Résultat", f"Aucun {job.lower()} trouvé sur {city}.")
        return

    log_text.insert(tk.END, "\n💾 Insertion dans Access...\n")
    root.update()
    insert_into_access(results)

    if messagebox.askokcancel("Fusion Word", "Voulez-vous générer les étiquettes maintenant ?"):
        fusion_word(imprimer=False)

def lancer_impression():
    if messagebox.askokcancel("Impression directe", "⚠ Fusion + impression directe.\nContinuer ?"):
        fusion_word(imprimer=True)

# ------------------- ✅ CHECK UPDATE -------------------
latest = check_update()
if latest:
    if messagebox.askokcancel("Mise à jour disponible", f"Nouvelle version {latest}.\nTélécharger ?"):
        do_update()

# ------------------- ✅ INTERFACE TKINTER SIMPLE -------------------
root = tk.Tk()
root.title(f"Import Pros bâtiment (v{CURRENT_VERSION}) → Access + Word")
root.geometry("950x600")

frame_top = tk.Frame(root)
frame_top.pack(pady=10, fill="x")

tk.Label(frame_top, text="Métier :").pack(side="left", padx=5)
combo_metier = ttk.Combobox(frame_top, values=list(keywords.keys()), width=20, state="readonly")
combo_metier.pack(side="left", padx=5)
combo_metier.set("Architectes")

tk.Label(frame_top, text="Ville :").pack(side="left", padx=5)
entry_ville = ttk.Entry(frame_top, width=30)
entry_ville.pack(side="left", padx=5)

btn_lancer = ttk.Button(frame_top, text="Import + Étiquettes", command=lancer_import)
btn_lancer.pack(side="left", padx=8)

btn_print = ttk.Button(frame_top, text="Fusion + Impression", command=lancer_impression)
btn_print.pack(side="left", padx=8)

progress_var = tk.IntVar()
progress = ttk.Progressbar(root, orient="horizontal", length=900, mode="determinate", variable=progress_var)
progress.pack(pady=10)

frame_log = tk.Frame(root)
frame_log.pack(fill="both", expand=True, padx=10, pady=8)
scrollbar = ttk.Scrollbar(frame_log, orient="vertical")
scrollbar.pack(side="right", fill="y")
log_text = tk.Text(frame_log, wrap="word", font=("Consolas",10), yscrollcommand=scrollbar.set)
log_text.pack(side="left", fill="both", expand=True)
scrollbar.config(command=log_text.yview)

root.mainloop()
