# --- CONFIGURATION ---
$workDir = "C:\Etiquettes"   # Chemin fixe
$desktop = [Environment]::GetFolderPath("Desktop")
$logFile = Join-Path $workDir "install_log.txt"

# Fonction log silencieux
function Log {
    param([string]$msg)
    Add-Content -Path $logFile -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg)
}

$scriptName = "Etiquettes.py"
$exeName = "Etiquettes.exe"
$iconPath = Join-Path $workDir "logo.ico"

"=== INSTALLATION ETIQUETTES ===" | Out-File $logFile

if (-not (Test-Path $iconPath)) {
    Log "⚠ Aucun fichier logo.ico trouvé, l’EXE aura l’icône par défaut."
    $useCustomIcon = $false
} else {
    Log "✅ Icône personnalisée détectée : $iconPath"
    $useCustomIcon = $true
}

# --- Vérifier Python après installation manuelle ---
$pythonPath = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $pythonPath) {
    Log "❌ Python n'est pas détecté après installation manuelle."
    Log "➡️ Vérifiez que vous avez bien coché 'Add Python to PATH' pendant l’installation."
    exit
} else {
    Log "✅ Python détecté : $($pythonPath.Source)"
}

# --- Installer les dépendances Python ---
Log "Installation des dépendances Python..."
pip install --upgrade pip >> $logFile 2>&1
pip install requests pywin32 pyinstaller pyodbc >> $logFile 2>&1
Log "✅ Modules Python installés : requests, pywin32, pyinstaller, pyodbc"

# --- Compiler le script en EXE ---
Log "Compilation du script en EXE..."
Set-Location $workDir

if ($useCustomIcon -eq $true) {
    pyinstaller --noconsole --onefile --icon "$iconPath" "$workDir\$scriptName" >> $logFile 2>&1
} else {
    pyinstaller --noconsole --onefile "$workDir\$scriptName" >> $logFile 2>&1
}

# --- Créer un raccourci sur le Bureau ---
Log "Création du raccourci sur le bureau..."
$exePath = Join-Path "$workDir\dist" $exeName
$shortcutPath = Join-Path $desktop "Etiquettes.lnk"   # ✅ NOM PROPRE DU RACCOURCI

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($shortcutPath)
$Shortcut.TargetPath = $exePath
$Shortcut.WorkingDirectory = Split-Path $exePath

if ($useCustomIcon -eq $true) {
    $Shortcut.IconLocation = $exePath  # L’EXE contient déjà l’icône
} else {
    $Shortcut.IconLocation = "shell32.dll, 1"
}

$Shortcut.Save()
Log "✅ Raccourci créé : $shortcutPath"

# --- Vérification du driver ODBC Access ---
$drivers = & python -c "import pyodbc; print(pyodbc.drivers())"
if ($drivers -like "*Microsoft Access Driver*") {
    Log "✅ Pilote ODBC Microsoft Access disponible."
} else {
    Log "⚠ Pilote ODBC Microsoft Access introuvable. Il faut Office ou Access Runtime."
}

Log "=== INSTALLATION TERMINEE ==="
